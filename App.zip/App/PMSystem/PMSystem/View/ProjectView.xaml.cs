﻿using System.Windows;
namespace PMSystem.View
{

    public partial class ProjectView : Window
    {
        public ProjectView()
        {
            InitializeComponent();
        }
    }
}
